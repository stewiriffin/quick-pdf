
  # Exciting App UI Design

  This is a code bundle for Exciting App UI Design. The original project is available at https://www.figma.com/design/0XXOVXAXVoBepm5XdlYjvb/Exciting-App-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  